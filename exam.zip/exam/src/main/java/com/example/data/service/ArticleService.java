package com.example.data.service;

public class ArticleService {
    public int getQuantiteDisponible() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getQuantiteDisponible'");
    }
    public void setQuantiteDisponible(int i) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setQuantiteDisponible'");
    }
}
