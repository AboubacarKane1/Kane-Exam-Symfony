package com.example.data.entity;

public class ArticleCommande {
    private int idAC;
    private float prixAC;
    private int qteAC;
    
    public int getIdAC() {
        return idAC;
    }
    public void setIdAC(int idAC) {
        this.idAC = idAC;
    }
    public float getPrixAC() {
        return prixAC;
    }
    public void setPrixAC(float prixAC) {
        this.prixAC = prixAC;
    }
    public int getQteAC() {
        return qteAC;
    }
    public void setQteAC(int qteAC) {
        this.qteAC = qteAC;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + idAC;
        result = prime * result + Float.floatToIntBits(prixAC);
        result = prime * result + qteAC;
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ArticleCommande other = (ArticleCommande) obj;
        if (idAC != other.idAC)
            return false;
        if (Float.floatToIntBits(prixAC) != Float.floatToIntBits(other.prixAC))
            return false;
        if (qteAC != other.qteAC)
            return false;
        return true;
    }
    public void setArticle(Article article) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setArticle'");
    }
    public void setQuantity(int quantity) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setQuantity'");
    }
    public void setCommande(Commande commande) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setCommande'");
    }
    public int getQuantity() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getQuantity'");
    }
    public Object getArticle() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getArticle'");
    }
}
