package com.example.data.repository;

import com.example.data.entity.Article;

public class ArticleRepository {

    public static void save(Article article) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'save'");
    }
    
}
