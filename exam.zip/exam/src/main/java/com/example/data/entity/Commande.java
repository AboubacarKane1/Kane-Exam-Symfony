package com.example.data.entity;

import java.util.ArrayList;

public class Commande {

    private int idCommande;
    private int dateCommande;
    private Client client;
    
    @Override
    public boolean equals(Object obj) {
        // TODO Auto-generated method stub
        return super.equals(obj);
    }
    @Override
    public int hashCode() {
        // TODO Auto-generated method stub
        return super.hashCode();
    }
    public int getIdCommande() {
        return idCommande;
    }
    public void setIdCommande(int idCommande) {
        this.idCommande = idCommande;
    }
    public int getDateCommande() {
        return dateCommande;
    }
    public void setDateCommande(int dateCommande) {
        this.dateCommande = dateCommande;
    }
    public Client getClient() {
        return client;
    }
    public void setClient(Client client) {
        this.client = client;
    }
    
}