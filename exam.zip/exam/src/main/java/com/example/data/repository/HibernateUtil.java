package com.example.data.repository;

import com.example.data.repository.hibernate.cfg.configuration;


public class HibernateUtil {
    private static SessionFactory sessionFactory;

    static {
        try {
            // Charger la configuration de hibernate.cfg.xml
            sessionFactory = new Configuration().configure().buildSessionFactory();
        } catch (Throwable ex) {
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public static void shutdown() {
        getSessionFactory().close();
    }
}
