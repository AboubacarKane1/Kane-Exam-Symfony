package com.example.data.service;

import com.example.data.entity.Commande;
import com.example.data.entity.Client;
import com.example.data.entity.Article;
import com.example.data.entity.ArticleCommande;
import com.example.data.repository.CommandeRepository;
import com.example.data.repository.ArticleCommandeRepository;
import com.example.data.repository.ArticleRepository;

import java.util.ArrayList;
import java.util.List;

public class CommandeService {
    private final CommandeRepository commandeRepository;
    private final ArticleCommandeRepository articleCommandeRepository;
    
    public CommandeService(CommandeRepository commandeRepository, ArticleCommandeRepository articleCommandeRepository) {
        this.commandeRepository = commandeRepository;
        this.articleCommandeRepository = articleCommandeRepository;
    }

    public Commande createCommande(Client client) {
        Commande commande = new Commande();
        commande.setClient(client);
        commande.setArticles(new ArrayList<>());
        return commandeRepository.save(commande);
    }

    public void addArticleToCommande(Commande commande, Article article, int quantity) {
        
        if (article.getQuantiteDisponible() >= quantity) {
            ArticleCommande articleCommande = new ArticleCommande();
            articleCommande.setArticle(article);
            articleCommande.setQuantity(quantity);
            articleCommande.setCommande(commande);
            articleCommandeRepository.save(articleCommande);

            
            article.setQuantiteDisponible(article.getQuantiteDisponible() - quantity);
            articleRepository.save(article);
        } else {
            throw new IllegalArgumentException("Quantité d'article insuffisante en stock.");
        }
    }

    public double calculateTotal(Commande commande) {
        double total = 0;
        for (ArticleCommande ac : commande.getArticles()) {
            total += ac.getQuantity() * ac.getArticle().getPrice();
        }
        return total;
    }

    public void validateCommande(Commande commande) {
        // Logique pour valider la commande (par exemple, marquer comme terminée, enregistrer dans la DB)
        commande.setStatus("VALIDATED");
        commandeRepository.save(commande);
    }

    public List<Commande> getAllCommandes() {
        return commandeRepository.findAll();
    }

    public Commande getCommandeById(Long id) {
        return commandeRepository.findById(id).orElseThrow(() -> new RuntimeException("Commande non trouvée"));
    }
}