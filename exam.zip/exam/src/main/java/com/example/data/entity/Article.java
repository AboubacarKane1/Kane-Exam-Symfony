package com.example.data.entity;

public class Article {
    private String idA;
    private String label;
    private int qte;
    private float prix;
    public float getPrix() {
        return prix;
    }
    public void setPrix(float prix) {
        this.prix = prix;
    }
    public String getIdA() {
        return idA;
    }
    public void setIdA(String idA) {
        this.idA = idA;
    }
    public String getLabel() {
        return label;
    }
    public void setLabel(String label) {
        this.label = label;
    }
    public int getQte() {
        return qte;
    }
    public void setQte(int qte) {
        this.qte = qte;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((idA == null) ? 0 : idA.hashCode());
        result = prime * result + ((label == null) ? 0 : label.hashCode());
        result = prime * result + qte;
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Article other = (Article) obj;
        if (idA == null) {
            if (other.idA != null)
                return false;
        } else if (!idA.equals(other.idA))
            return false;
        if (label == null) {
            if (other.label != null)
                return false;
        } else if (!label.equals(other.label))
            return false;
        if (qte != other.qte)
            return false;
        return true;
    }
    @Override
    public String toString() {
        return "Article [idA=" + idA + ", label=" + label + ", qte=" + qte + ", prix=" + prix;
    }
    
}
