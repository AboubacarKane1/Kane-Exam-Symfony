package com.example.data.service;
import com.example.data.entity.Client;
import com.example.data.repository.ClientRepository;

public class ClientService {
    private ClientRepository clientRepository = new ClientRepository();

    public Client chercherParTelephone(String telephone) {
        return clientRepository.findByTelephone(telephone);
    }
}
