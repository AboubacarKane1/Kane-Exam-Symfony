package com.example.data.repository;

import com.example.data.repository.HibernateUtil;

import jakarta.transaction.Transaction;

import javax.management.Query;
import com.example.data.entity.Client;


public class ClientRepository {
    public Client findByTelephone(String telephone) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Query<Client> query = session.createQuery("FROM Client WHERE telephone = :telephone", Client.class);
        query.setParameter("telephone", telephone);
        Client client = query.uniqueResult();
        session.close();
        return client;
    }

    public void save(Client client) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        session.save(client);
        transaction.commit();
        session.close();
    }

    
}
