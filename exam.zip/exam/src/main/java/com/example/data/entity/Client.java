package com.example.data.entity;

public class Client {
    private int idC;
    private String nomC;
    private String prenomC;
    private String telephone;

    private Adresse adresse;

    public int getIdC() {
        return idC;
    }

    public void setIdC(int idC) {
        this.idC = idC;
    }

    public String getNomC() {
        return nomC;
    }

    public void setNomC(String nomC) {
        this.nomC = nomC;
    }

    public String getPrenomC() {
        return prenomC;
    }

    public void setPrenomC(String prenomC) {
        this.prenomC = prenomC;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public Adresse getAdresse() {
        return adresse;
    }

    public void setAdresse(Adresse adresse) {
        this.adresse = adresse;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + idC;
        result = prime * result + ((nomC == null) ? 0 : nomC.hashCode());
        result = prime * result + ((prenomC == null) ? 0 : prenomC.hashCode());
        result = prime * result + ((telephone == null) ? 0 : telephone.hashCode());
        result = prime * result + ((adresse == null) ? 0 : adresse.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Client other = (Client) obj;
        if (idC != other.idC)
            return false;
        if (nomC == null) {
            if (other.nomC != null)
                return false;
        } else if (!nomC.equals(other.nomC))
            return false;
        if (prenomC == null) {
            if (other.prenomC != null)
                return false;
        } else if (!prenomC.equals(other.prenomC))
            return false;
        if (telephone == null) {
            if (other.telephone != null)
                return false;
        } else if (!telephone.equals(other.telephone))
            return false;
        if (adresse == null) {
            if (other.adresse != null)
                return false;
        } else if (!adresse.equals(other.adresse))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "Client [idC=" + idC + ", nomC=" + nomC + ", prenomC=" + prenomC + ", telephone=" + telephone
                + ", adresse=" + adresse + "]";
    }
}

