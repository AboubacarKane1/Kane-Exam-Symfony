package com.example.data.repository;

import com.example.data.entity.ArticleCommande;

public class ArticleCommandeRepository {

    public void save(ArticleCommande articleCommande) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'save'");
    }
    
}
