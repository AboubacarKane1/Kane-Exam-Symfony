package com.example.data.entity;

public class Adresse {
    private String ville;
    private String quartier;
    private String numeroVilla;
    public String getVille() {
        return ville;
    }
    public void setVille(String ville) {
        this.ville = ville;
    }
    public String getQuartier() {
        return quartier;
    }
    public void setQuartier(String quartier) {
        this.quartier = quartier;
    }
    public String getNumeroVilla() {
        return numeroVilla;
    }
    public void setNumeroVilla(String numeroVilla) {
        this.numeroVilla = numeroVilla;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((ville == null) ? 0 : ville.hashCode());
        result = prime * result + ((quartier == null) ? 0 : quartier.hashCode());
        result = prime * result + ((numeroVilla == null) ? 0 : numeroVilla.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Adresse other = (Adresse) obj;
        if (ville == null) {
            if (other.ville != null)
                return false;
        } else if (!ville.equals(other.ville))
            return false;
        if (quartier == null) {
            if (other.quartier != null)
                return false;
        } else if (!quartier.equals(other.quartier))
            return false;
        if (numeroVilla == null) {
            if (other.numeroVilla != null)
                return false;
        } else if (!numeroVilla.equals(other.numeroVilla))
            return false;
        return true;
    }
    @Override
    public String toString() {
        return "Adresse [ville=" + ville + ", quartier=" + quartier + ", numeroVilla=" + numeroVilla + "]";
    }
    
}
